<?php

declare(strict_types=1);

namespace App\Exception;

require_once("AppException.php");

class ConfigurationException extends AppException
{
}
