<?php

declare(strict_types=1);

namespace App\Exception;

require_once('AppException.php');

use App\Exception\AppException;

class NotFoundException extends AppException
{
}
