<?php

declare(strict_types=1);

return[
    'db' =>[
    'host' => 'mysql.cba.pl',
    'database' => 'projektaplikacjeinternetowe',
    'user' => 'projektap1',
    'password' => '1234567Aa'
    ]
];
?>